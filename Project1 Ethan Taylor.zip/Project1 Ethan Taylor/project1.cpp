//Ethan Taylor

#define _CRT_SECURE_NO_WARNINGS
#include <ctime>
#include <iostream>
using namespace std;

//Time class
class Time {
public:
	int h1, h2;
	int m1, m2;
	int s1, s2;
	//constructor for clock
	Time() {
		this->h1 = 12;
		this->m1 = 0;
		this->s1 = 0;
		this->h2 = 0;
		this->m2 = 0;
		this->s2 = 0;
	}

	//set limits so hours and minutes are less than 60
	void timeLimit(int t = 1) {
		if (t == 1) {
			if (s1 / 60 > 0) {
				s1 %= 60;
				m1 = m1 + 1;
			}
			if (m1 / 60 > 0) {
				m1 %= 60;
				h1 = h1 + 1;
			}
			if (h1 / 12 > 0) {
				h1 %= 12;
			}
		}
		if (t == 2) {
			if (s2 / 60 > 0) {
				s2 %= 60;
				m2 = m2 + 1;
			}
			if (m2 / 60 > 0) {
				m2 %= 60;
				h2 = h2 + 1;
			}
			if (h2 / 24 > 0) {
				h2 %= 24;
			}
		}
	}
	//functions to add time or wait
	//seconds
	void addSecond() {
		s1 = s1 + 1;
		s2 = s2 + 1;
		timeLimit(1);
		timeLimit(2);
	}
	void waitSecond() {
		s1 = s1 + 1;
		s2 = s2 + 1;
		timeLimit(1);
		timeLimit(2);
	}
	//minutes
	void addMinute() {
		m1 = m1 + 1;
		m2 = m2 + 1;
		timeLimit(1);
		timeLimit(2);
	}
	void waitMinute() {
		m1 = m1 + 1;
		m2 = m2 + 1;
		timeLimit(1);
		timeLimit(2);
	}
	//hours
	void addHour() {
		h1 = h1 + 1;
		h2 = h2 + 1;
		timeLimit(1);
		timeLimit(2);
	}
	void waitHour() {
		h1 = h1 + 1;
		h2 = h2 + 1;
		timeLimit(1);
		timeLimit(2);
	}
	//display times
	void display(){
		printf("\nTime1: %02d:%02d%02d\n", h1, m1, s1);
		printf("Time2: %02d:%02d%02d\n\n", h2, m2, s2);
	}
};

int main() {
	Time t;
	int option1 = 1;
	int choice1, choice2, addTime;

	//Menu
	while (option1 > 0) {
		t.display();
		cout << "Change time? (1 for yes, 2 for no): " << endl;
		cin >> choice1;
		if (choice1 == 1) {
			cout << "Choose option\n1:Add time\n2:Exit: ";
			cin >> choice2;

			if (choice2 == 1) {
				cout << "1:Add one hour\n2:Add one minute\n3:Add one second: ";
				cin >> addTime;

				//Add time to hours, minutes or seconds
				switch (addTime) {
				case 1: t.addHour();
					break;
				case 2: t.addMinute();
					break;
				case 3: t.addSecond();
					break;
				}
			}
			if (choice2 == 2) {
				addTime = -1;
			}
		}
		else if (choice1 == 2) {
			t.addSecond();
			t.waitSecond();
		}
	}
}